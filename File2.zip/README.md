# Iraqi Customs Calculator - Deployment Guide

## 📁 File Structure

```
customs-calculator/
├── index.html          # Main HTML file
├── css/
│   └── style.css       # Stylesheet
├── js/
│   ├── app.js          # Main application logic
│   └── data.js         # HS Code database (1,667 entries)
└── README.md           # This file
```

## 🚀 Deployment on Hostinger

### Method 1: File Manager (Easiest)

1. **Login to Hostinger** → Go to hPanel
2. **Open File Manager** → Navigate to `public_html`
3. **Upload Files**:
   - Upload `index.html` directly to `public_html`
   - Create folder `css` → Upload `style.css`
   - Create folder `js` → Upload `app.js` and `data.js`
4. **Done!** Visit your domain to see the calculator

### Method 2: FTP Upload

1. **Get FTP credentials** from Hostinger hPanel
2. **Connect using FileZilla** or any FTP client
3. **Upload** the entire `customs-calculator` folder contents to `public_html`

### Method 3: Git (Advanced)

1. Push this folder to GitHub
2. In Hostinger hPanel → Go to **Git**
3. Connect your repository
4. Deploy to `public_html`

---

## 📢 Adding Google AdSense

### Step 1: Get AdSense Code

1. Go to [Google AdSense](https://www.google.com/adsense/)
2. Create an account and get approved
3. Create ad units (recommended sizes below)

### Step 2: Add AdSense Script

In `index.html`, find this line near the top:

```html
<!-- <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-XXXXXXXXXXXXXXXX" crossorigin="anonymous"></script> -->
```

Replace `ca-pub-XXXXXXXXXXXXXXXX` with your AdSense publisher ID and remove the comment marks.

### Step 3: Replace Ad Placeholders

Find the `<div class="ad-demo">` sections and replace with your AdSense ad code:

**Top Banner (728x90):**
```html
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
     data-ad-slot="XXXXXXXXXX"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
```

**Sidebar (160x600):**
```html
<ins class="adsbygoogle"
     style="display:inline-block;width:160px;height:600px"
     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
     data-ad-slot="XXXXXXXXXX"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
```

**In-Content (336x280):**
```html
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
     data-ad-slot="XXXXXXXXXX"></ins>
<script>(adsbygoogle = window.adsbygoogle || []).push({});</script>
```

### Recommended Ad Sizes:
- **Top/Bottom Banner**: 728x90 (Leaderboard)
- **Sidebars**: 160x600 (Wide Skyscraper)
- **In-Content**: 336x280 (Large Rectangle)
- **Mobile**: 320x100 (Large Mobile Banner)

---

## ⚙️ Configuration

### Change Exchange Rate

In `js/app.js`, find and modify:
```javascript
const USD_TO_IQD = 1320;
```

### Update HS Code Data

1. Export new data from your Excel file
2. Format as JSON with this structure:
```json
{
  "HS_CODE": {
    "hs_code": "HS_CODE",
    "description": "Description",
    "tariff_rate": 10,
    "additional_rate": 3,
    "avr_mnt": 2.5,
    "avr_unt": "KGM",
    "avr_unt_nam": "كيلو غرام"
  }
}
```
3. Replace contents of `js/data.js`

---

## 🔧 Troubleshooting

### "HS Code not found" Error
- Check if the code exists in `data.js`
- Only codes with `avr_mnt` values are included

### Page Not Loading
- Verify all files are uploaded
- Check file paths are correct
- Clear browser cache

### Ads Not Showing
- Wait 24-48 hours after adding AdSense
- Check AdSense dashboard for issues
- Ensure your site complies with AdSense policies

---

## 📱 Mobile Support

The calculator is fully responsive and works on:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (< 768px)

Sidebars ads are hidden on screens smaller than 1200px.

---

## 📄 License

This calculator is for educational and commercial use.
Data based on Iraqi Customs Tariff 2026 and Cabinet Decision 957.

---

## 🆘 Support

For technical issues or questions, please contact the developer.
